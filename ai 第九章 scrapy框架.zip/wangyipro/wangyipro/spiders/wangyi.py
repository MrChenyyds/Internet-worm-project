import scrapy
from selenium import webdriver
from wangyipro.items import WangyiproItem

class WangyiSpider(scrapy.Spider):
    name = 'wangyi'
    # allowed_domains = ['www.xxx.com']
    start_urls = ['https://news.163.com/']
    detail_list = []

    def __init__(self):
        self.br = webdriver.Chrome(executable_path='D:\document\python3Project\爬虫学习\\ai 第九章 scrapy框架\\boss\chromedriver.exe')

    def parse(self, response):

        li_list = response.xpath('//div[@class="ns_area list"]/ul/li')
        a_list = [2,3]

        for index in a_list:
           href = li_list[index].xpath('./a/@href').extract_first()
           self.detail_list.append(href)

        for url in self.detail_list:
            yield scrapy.Request(url,callback=self.detail_parse)

    def detail_parse(self, response):
        div_list = response.xpath('//div[@class="ndi_main"]/div')
        for div in div_list:
            title = div.xpath('./div/div[1]/h3/a/text()').extract_first()
            news_detail_url = div.xpath('./div/div[1]/h3/a/@href').extract_first()

            item =WangyiproItem()
            item['title'] = title

            yield scrapy.Request(news_detail_url,callback=self.news_detail_parse,meta={'item':item})

    def news_detail_parse(self,response):

        content = response.xpath('//div[@class="post_body"]//text()').extract()
        content = ''.join(content)
        item = response.meta['item']
        item['content'] = content

        yield item

    def closed(self,spider):
        self.br.quit()

