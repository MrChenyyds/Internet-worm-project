import scrapy


class Scrapy使用Spider(scrapy.Spider):
    name = 'scrapy使用'
    # allowed_domains = ['www.xxxx.com']
    start_urls = ['http://www.baidu.com/']

    def parse(self, response):
        print(response)
