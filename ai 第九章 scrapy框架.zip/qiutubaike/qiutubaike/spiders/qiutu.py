import scrapy
from qiutubaike.items import QiutubaikeItem

class QiutuSpider(scrapy.Spider):
    name = 'qiutu'
    # allowed_domains = ['www.xxx.com']
    start_urls = ['https://www.qiushibaike.com/text/']
    # 1.  终端存储方式
    # def parse(self, response):
    #     all_data = []
    #     div_list = response.xpath('//div[@class="col1 old-style-col1"]/div')
    #     for div in div_list:
    #         author = div.xpath('./div[1]/a[2]/h2').extract_first()
    #         content = div.xpath('./a[1]/div[1]/span//text()').extract()
    #         content = ''.join(content)
    #         data = {
    #             'author':author,
    #             'content':content
    #         }
    #         all_data.append(data)
    #     return all_data
    # # scrapy crawl qiutu -o ./qiutudata.csv


    #2. 管道存储方式
    def parse(self, response):

        div_list = response.xpath('//div[@class="col1 old-style-col1"]/div')
        for div in div_list:
            author = div.xpath('./div[1]/a[2]/h2').extract_first()
            content = div.xpath('./a[1]/div[1]/span//text()').extract()
            content = ''.join(content)

            item = QiutubaikeItem()
            item['author'] = author
            item['content'] = content

            yield item